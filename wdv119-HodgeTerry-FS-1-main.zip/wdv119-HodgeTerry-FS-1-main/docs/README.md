# Docs.

This folder is for miscellaneous documentation. 

It's common for repositories to contain documentation provided by the developers or team working on projects together.   

In this class you may be asked to work on documentation that can be stored in this folder. 














